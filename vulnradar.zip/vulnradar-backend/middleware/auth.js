const jwt = require('jsonwebtoken');

// برای مسیرهایی که حتماً باید لاگین باشند
function requireAuth(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'وارد حساب کاربری نشده‌اید' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = payload.uid;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'نشست منقضی یا نامعتبر است، دوباره وارد شوید' });
  }
}

// برای مسیرهایی که لاگین اختیاری است (مثلاً صفحه‌ی اصلی)
function optionalAuth(req, res, next) {
  const token = req.cookies.token;
  if (token) {
    try {
      req.userId = jwt.verify(token, process.env.JWT_SECRET).uid;
    } catch (e) {
      /* توکن نامعتبر -> کاربر مهمان در نظر گرفته می‌شود */
    }
  }
  next();
}

module.exports = { requireAuth, optionalAuth };
