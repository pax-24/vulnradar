require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const authRoutes = require('./routes/auth');
const accountRoutes = require('./routes/account');

const app = express();
app.set('trust proxy', 1); // چون پشت Nginx اجرا می‌شود

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json());
app.use(cookieParser());

// محدودیت تعداد درخواست روی مسیرهای حساس auth برای کاهش ریسک brute-force
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30 });

app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/account', accountRoutes);

// فایل‌های فرانت‌اند (index.html و غیره) از پوشه‌ی public سرو می‌شوند
app.use(express.static(path.join(__dirname, 'public')));

// چون فرانت‌اند روتینگ خودش را با hash (#/...) انجام می‌دهد،
// هر مسیری که با /api شروع نشود باید همان index.html را برگرداند
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`VulnRadar در حال اجرا روی پورت ${PORT}`);
});
