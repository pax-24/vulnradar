# راهنمای دیپلوی VulnRadar (بک‌اند واقعی + دامنه‌ی .ir)

این پروژه دیگر به فایربیس وابسته نیست. یک سرور Node.js/Express دارید که هم فرانت‌اند را سرو می‌کند
و هم API واقعی لاگین/ثبت‌نام را با PostgreSQL مدیریت می‌کند.

---

## ۱) خرید VPS

یک سرور مجازی با مشخصات حداقلی زیر کافی است:
- Ubuntu 22.04 LTS
- ۱ هسته CPU، ۱ تا ۲ گیگ RAM، حدود ۲۵ گیگ SSD

گزینه‌های ایرانی (پرداخت تومانی، بدون مشکل تحریم):
- **آروان‌کلود (ArvanCloud)** — Cloud Server
- پارس‌پک، توسکا، ایران‌سرور و مشابه

بعد از خرید، یک آی‌پی عمومی (مثلاً `1.2.3.4`) و اطلاعات SSH (کاربر `root` و رمز یا کلید) به شما داده می‌شود.

---

## ۲) اتصال به سرور و نصب پیش‌نیازها

```bash
ssh root@YOUR_SERVER_IP

# به‌روزرسانی سیستم
apt update && apt upgrade -y

# نصب Node.js نسخه‌ی LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# نصب PostgreSQL
apt install -y postgresql postgresql-contrib

# نصب Nginx (برای reverse proxy و SSL)
apt install -y nginx

# نصب PM2 (نگه‌دارنده‌ی پروسه‌ی Node در پس‌زمینه)
npm install -g pm2
```

---

## ۳) ساخت دیتابیس

```bash
sudo -u postgres psql
```
داخل psql:
```sql
CREATE DATABASE vulnradar;
CREATE USER vulnradar_user WITH ENCRYPTED PASSWORD 'یک-رمز-قوی-بسازید';
GRANT ALL PRIVILEGES ON DATABASE vulnradar TO vulnradar_user;
\q
```
سپس schema را اجرا کنید (بعد از آپلود پروژه، مرحله‌ی بعد):
```bash
psql -U vulnradar_user -d vulnradar -h localhost -f schema.sql
```

---

## ۴) آپلود پروژه روی سرور

از روی کامپیوتر خودتان (نه داخل سرور):
```bash
scp -r vulnradar-backend root@YOUR_SERVER_IP:/var/www/
```

روی سرور:
```bash
cd /var/www/vulnradar-backend
cp .env.example .env
nano .env   # مقادیر DATABASE_URL و JWT_SECRET را با مقادیر واقعی پر کنید

# برای ساخت یک JWT_SECRET قوی:
openssl rand -hex 32

npm install --production
```

---

## ۵) اجرای دائمی سرور با PM2

```bash
pm2 start server.js --name vulnradar
pm2 save
pm2 startup     # دستوری که چاپ می‌شود را کپی و اجرا کنید تا بعد از ریبوت هم بالا بیاید
```

سرور الان روی پورت داخلی `3000` در حال اجراست.

---

## ۶) دامنه‌ی .ir

1. یک دامنه‌ی `.ir` از طریق یکی از شرکت‌های مجاز ثبت دامنه (معمولاً همان شرکتی که VPS را از آن گرفتید
   هم این خدمت را دارد، یا مستقیم از طریق `nic.ir`) ثبت کنید. برای ثبت دامنه‌ی `.ir` به‌عنوان شخص حقیقی
   معمولاً کد ملی لازم است.
2. در پنل دامنه، یک رکورد **A** بسازید که `yourdomain.ir` را به آی‌پی VPS (`YOUR_SERVER_IP`) وصل کند.
3. انتشار DNS معمولاً چند ساعت طول می‌کشد.

---

## ۷) تنظیم Nginx + SSL رایگان

فایل کانفیگ بسازید:
```bash
nano /etc/nginx/sites-available/vulnradar
```
محتوا:
```nginx
server {
    listen 80;
    server_name yourdomain.ir www.yourdomain.ir;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
فعال‌سازی:
```bash
ln -s /etc/nginx/sites-available/vulnradar /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

نصب SSL رایگان با Let's Encrypt:
```bash
apt install -y certbot python3-certbot-nginx
certbot --nginx -d yourdomain.ir -d www.yourdomain.ir
```

بعد از گرفتن SSL، در فایل `.env` مقدار زیر را بگذارید و سرور را ریستارت کنید تا کوکی لاگین روی HTTPS درست کار کند:
```
COOKIE_SECURE=true
```
```bash
pm2 restart vulnradar
```

---

## ۸) تست نهایی

به آدرس `https://yourdomain.ir` بروید، یک حساب بسازید، خروج و ورود را امتحان کنید.
اگر صفحه‌ی لاگین خطای کوکی داد، مرحله‌ی SSL را چک کنید (`COOKIE_SECURE=true` فقط روی HTTPS کار می‌کند).

---

## نکته‌ی مهم درباره‌ی پرداخت/ارتقای اشتراک

دکمه‌ی «ارتقا» در صفحه‌ی قیمت‌گذاری فعلاً فقط یک endpoint توسعه‌ای (`/api/account/tier-dev-only`)
را صدا می‌زند و واقعاً پولی دریافت نمی‌شود. وقتی خواستید درگاه پرداخت واقعی (مثل زرین‌پال، آیدی‌پی یا زیبال)
وصل کنید، باید:
1. کاربر را به صفحه‌ی پرداخت درگاه هدایت کنید.
2. بعد از پرداخت، درگاه یک callback به سرور شما می‌زند.
3. فقط داخل آن callback (بعد از تأیید واقعی تراکنش در سمت سرور) ستون `tier` را آپدیت کنید.
4. مسیر `/api/account/tier-dev-only` را همان موقع حذف کنید.

هر وقت آماده بودید برای وصل کردن یک درگاه پرداخت ایرانی، بگو تا کد callback آن را هم بسازم.
