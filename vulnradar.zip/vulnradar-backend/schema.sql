-- اجرای این فایل: psql -U vulnradar_user -d vulnradar -f schema.sql

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  tier          VARCHAR(10) NOT NULL DEFAULT 'free' CHECK (tier IN ('free','plus','pro')),
  bookmarks     JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);
