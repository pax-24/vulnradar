const express = require('express');
const router = express.Router();
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');

/**
 * ⚠️ نکته‌ی امنیتی مهم — قبل از انتشار واقعی این بخش را بخوانید:
 *
 * این endpoint به کاربر اجازه می‌دهد سطح اشتراک خودش را مستقیماً عوض کند،
 * بدون اینکه پرداختی واقعاً انجام شده باشد. این فقط برای توسعه/دمو است.
 *
 * وقتی درگاه پرداخت (مثلاً زرین‌پال) را وصل کردید:
 *   1) این مسیر را کاملاً حذف کنید یا پشت یک پرچم محیطی (NODE_ENV=development) قفل کنید.
 *   2) به‌جایش یک callback از سمت درگاه پرداخت بسازید که بعد از تأیید تراکنش
 *      در سمت سرور، خودش UPDATE روی ستون tier بزند — کلاینت هرگز نباید
 *      بتواند مستقیماً tier را به plus/pro تغییر بدهد.
 */
router.patch('/tier-dev-only', requireAuth, async (req, res) => {
  const { tier } = req.body || {};
  if (!['free', 'plus', 'pro'].includes(tier)) {
    return res.status(400).json({ error: 'مقدار tier نامعتبر است' });
  }
  await pool.query('UPDATE users SET tier = $1 WHERE id = $2', [tier, req.userId]);
  res.json({ ok: true, tier });
});

router.post('/bookmarks/toggle', requireAuth, async (req, res) => {
  const { articleId } = req.body || {};
  if (!articleId) return res.status(400).json({ error: 'articleId لازم است' });
  const result = await pool.query('SELECT bookmarks FROM users WHERE id = $1', [req.userId]);
  if (!result.rows.length) return res.status(404).json({ error: 'حساب یافت نشد' });
  let list = result.rows[0].bookmarks || [];
  if (list.includes(articleId)) list = list.filter((x) => x !== articleId);
  else list.push(articleId);
  await pool.query('UPDATE users SET bookmarks = $1 WHERE id = $2', [JSON.stringify(list), req.userId]);
  res.json({ bookmarks: list });
});

module.exports = router;
