const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const router = express.Router();
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function issueSession(res, user) {
  const token = jwt.sign({ uid: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });
  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.COOKIE_SECURE === 'true',
    sameSite: 'lax',
    maxAge: 30 * 24 * 60 * 60 * 1000
  });
}

// ثبت‌نام — همیشه با سطح "free" شروع می‌شود.
// ارتقای سطح فقط باید بعد از تأیید واقعی پرداخت انجام شود (نه در این مرحله).
router.post('/register', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !EMAIL_RE.test(email)) {
      return res.status(400).json({ error: 'ایمیل وارد شده معتبر نیست' });
    }
    if (!password || password.length < 8) {
      return res.status(400).json({ error: 'رمز عبور باید حداقل ۸ کاراکتر باشد' });
    }
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'حسابی با این ایمیل قبلاً ساخته شده است' });
    }
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, tier) VALUES ($1, $2, 'free')
       RETURNING id, email, tier, bookmarks`,
      [email, hash]
    );
    const user = result.rows[0];
    issueSession(res, user);
    res.json({ user });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'خطای سرور، دوباره تلاش کنید' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'ایمیل و رمز عبور لازم است' });
    const result = await pool.query(
      'SELECT id, email, password_hash, tier, bookmarks FROM users WHERE email = $1',
      [email]
    );
    if (!result.rows.length) return res.status(401).json({ error: 'ایمیل یا رمز عبور اشتباه است' });
    const user = result.rows[0];
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'ایمیل یا رمز عبور اشتباه است' });
    issueSession(res, user);
    res.json({ user: { id: user.id, email: user.email, tier: user.tier, bookmarks: user.bookmarks } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'خطای سرور، دوباره تلاش کنید' });
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

router.get('/me', requireAuth, async (req, res) => {
  const result = await pool.query(
    'SELECT id, email, tier, bookmarks FROM users WHERE id = $1',
    [req.userId]
  );
  if (!result.rows.length) return res.status(404).json({ error: 'حساب یافت نشد' });
  res.json({ user: result.rows[0] });
});

module.exports = router;
